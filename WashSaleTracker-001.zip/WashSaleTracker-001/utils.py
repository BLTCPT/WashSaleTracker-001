import pandas as pd
from datetime import datetime
import re

def format_currency(amount):
    """Format a number as currency with $ sign."""
    return f"${amount:,.2f}"

def format_percentage(value):
    """Format a number as percentage."""
    return f"{value:.2f}%"

def parse_date_column(date_series):
    """
    Parse date strings from various formats into datetime objects.
    Handles different date formats commonly found in broker exports.
    
    Args:
        date_series: Pandas Series containing date strings
        
    Returns:
        Pandas Series with parsed datetime objects
    """
    # First, check if it's already in datetime format
    if pd.api.types.is_datetime64_any_dtype(date_series):
        return date_series
    
    # Convert to string to ensure consistent handling
    date_series = date_series.astype(str)
    
    # Try different parsing approaches
    parsed_dates = []
    
    for date_str in date_series:
        # Remove any timezone indicators in parentheses
        date_str = re.sub(r'\([^)]*\)', '', date_str).strip()
        
        # Check for timestamp format with timezone offset (like in the sample data)
        if re.search(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d+-\d{2}:\d{2}', date_str):
            try:
                # For timestamp format with timezone like '2025-01-02 15:53:29.003015-05:00'
                parsed_date = pd.to_datetime(date_str, format='%Y-%m-%d %H:%M:%S.%f%z')
                parsed_dates.append(parsed_date)
                continue
            except:
                pass
        
        # Try different date formats
        formats = [
            '%Y-%m-%d %H:%M:%S',
            '%Y-%m-%d %H:%M:%S.%f',
            '%Y-%m-%d',
            '%m/%d/%Y %H:%M:%S',
            '%m/%d/%Y',
            '%d-%m-%Y %H:%M:%S',
            '%d/%m/%Y',
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%f'
        ]
        
        parsed_date = None
        for fmt in formats:
            try:
                parsed_date = pd.to_datetime(date_str, format=fmt)
                break
            except (ValueError, TypeError):
                continue
        
        if parsed_date is None:
            # If all explicit formats fail, try pandas default parser
            try:
                parsed_date = pd.to_datetime(date_str)
            except:
                # If everything fails, use today's date and log it
                print(f"Could not parse date: {date_str}")
                parsed_date = pd.Timestamp.now()
        
        parsed_dates.append(parsed_date)
    
    return pd.Series(parsed_dates)
