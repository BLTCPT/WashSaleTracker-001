import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def detect_wash_sales(df, window_days=30, year_end_analysis=False):
    """
    Detects wash sales in transaction data.
    
    A wash sale occurs when:
    1. An investor sells a security at a loss
    2. Buys a "substantially identical" security within the specified window days (default 30)
       before or after the sale
    
    Args:
        df: DataFrame with columns: date, symbol, side, quantity, price
        window_days: Number of days to consider for wash sale detection (default: 30)
        year_end_analysis: Whether to perform year-end analysis for tax loss harvesting (default: False)
        
    Returns:
        Dictionary with:
            - wash_sales: DataFrame of detected wash sales
            - summary: Summary statistics
            - tax_loss_harvest: DataFrame of tax loss harvesting opportunities (if enabled)
            - multi_year: DataFrame with cross-year wash sale analysis (if year_end_analysis is True)
    """
    # Ensure columns are properly formatted
    required_columns = ['date', 'symbol', 'side', 'quantity', 'price']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Required column '{col}' missing from input data")
    
    # Ensure df is sorted by date
    df = df.sort_values('date').reset_index(drop=True)
    
    # Convert sides to lowercase for consistent comparison
    df['side'] = df['side'].str.lower()
    
    # Add year column for year-end analysis
    df['year'] = df['date'].dt.year
    
    # Debug the years in the data
    unique_years = sorted(df['year'].unique())
    print(f"Years found in the dataset: {unique_years}")
    
    # Initialize results
    wash_sales = []
    tax_loss_harvest_opportunities = []
    cross_year_wash_sales = []
    
    # Loop through sell transactions
    sell_transactions = df[df['side'].str.contains('sell')]
    
    for _, sell_row in sell_transactions.iterrows():
        symbol = sell_row['symbol']
        sell_date = sell_row['date']
        sell_price = sell_row['price']
        sell_quantity = sell_row['quantity']
        sell_year = sell_row['year']
        
        # Filter buy transactions of the same symbol within window days
        window_start = sell_date - timedelta(days=window_days)
        window_end = sell_date + timedelta(days=window_days)
        
        buy_transactions = df[
            (df['symbol'] == symbol) & 
            (df['side'].str.contains('buy')) & 
            (df['date'] >= window_start) & 
            (df['date'] <= window_end)
        ]
        
        # Check for tax loss harvesting opportunities
        # If no buys within window and sell price is lower than cost basis
        if buy_transactions.empty:
            # Find previous buys to calculate cost basis
            previous_buys = df[
                (df['symbol'] == symbol) & 
                (df['side'].str.contains('buy')) & 
                (df['date'] < sell_date)
            ]
            
            if not previous_buys.empty:
                avg_cost_basis = previous_buys['price'].mean()
                if sell_price < avg_cost_basis:
                    # Calculate realized loss
                    realized_loss = (avg_cost_basis - sell_price) * sell_quantity
                    
                    tax_loss_harvest_opportunities.append({
                        'date': sell_date,
                        'symbol': symbol,
                        'quantity': sell_quantity,
                        'sell_price': sell_price,
                        'cost_basis': avg_cost_basis,
                        'realized_loss': realized_loss,
                        'year': sell_year
                    })
            
            continue
        
        # For each buy transaction, check if it creates a wash sale
        for _, buy_row in buy_transactions.iterrows():
            buy_date = buy_row['date']
            buy_price = buy_row['price']
            buy_quantity = buy_row['quantity']
            buy_year = buy_row['year']
            
            # Calculate loss per share (positive value means a loss)
            # For proper wash sale detection, we should compare against cost basis, 
            # but for simplicity, we use buy_price as reference
            loss_per_share = sell_price - buy_price
            
            if loss_per_share < 0:  # Only if there's a loss (negative value)
                # Convert to positive value for easier understanding
                loss_per_share = abs(loss_per_share)
                days_between = abs((buy_date - sell_date).days)
                
                # Calculate the disallowed loss
                matched_quantity = min(sell_quantity, buy_quantity)
                disallowed_loss = loss_per_share * matched_quantity
                
                # Create wash sale data dictionary
                wash_sale_data = {
                    'sell_date': sell_date,
                    'symbol': symbol,
                    'sell_quantity': sell_quantity,
                    'sell_price': sell_price,
                    'buy_date': buy_date,
                    'buy_quantity': buy_quantity,
                    'buy_price': buy_price,
                    'days_between': days_between,
                    'loss_per_share': loss_per_share,
                    'disallowed_loss': disallowed_loss,
                    'sell_year': sell_year,
                    'buy_year': buy_year
                }
                
                # Add Order IDs when available (for tracking and avoiding duplicates)
                if hasattr(sell_row, 'order_id'):
                    wash_sale_data['sell_order_id'] = sell_row.order_id
                if hasattr(buy_row, 'order_id'):
                    wash_sale_data['buy_order_id'] = buy_row.order_id
                    
                # Add source file info if available
                if hasattr(sell_row, 'source_file'):
                    wash_sale_data['sell_file'] = sell_row.source_file
                if hasattr(buy_row, 'source_file'):
                    wash_sale_data['buy_file'] = buy_row.source_file
                
                wash_sales.append(wash_sale_data)
                
                # Check for cross-year wash sales
                if year_end_analysis and sell_year != buy_year:
                    cross_year_wash_sales.append(wash_sale_data)
                    # Debug info for cross-year detection
                    print(f"Cross-year wash sale detected: {symbol} - Sell: {sell_date} ({sell_year}), Buy: {buy_date} ({buy_year})")
    
    # Create DataFrames from results
    wash_sales_df = pd.DataFrame(wash_sales)
    tax_loss_harvest_df = pd.DataFrame(tax_loss_harvest_opportunities)
    cross_year_wash_sales_df = pd.DataFrame(cross_year_wash_sales)
    
    # Remove duplicates based on Order IDs if available
    if not wash_sales_df.empty and 'sell_order_id' in wash_sales_df.columns and 'buy_order_id' in wash_sales_df.columns:
        # Create a composite key from sell_order_id and buy_order_id
        wash_sales_df['order_key'] = wash_sales_df['sell_order_id'] + '_' + wash_sales_df['buy_order_id']
        # Drop duplicates based on this key
        wash_sales_df = wash_sales_df.drop_duplicates(subset=['order_key'])
        # Remove the temporary key
        wash_sales_df = wash_sales_df.drop(columns=['order_key'])
        
        # Also update cross-year wash sales to remove duplicates
        if not cross_year_wash_sales_df.empty and 'sell_order_id' in cross_year_wash_sales_df.columns and 'buy_order_id' in cross_year_wash_sales_df.columns:
            cross_year_wash_sales_df['order_key'] = cross_year_wash_sales_df['sell_order_id'] + '_' + cross_year_wash_sales_df['buy_order_id']
            cross_year_wash_sales_df = cross_year_wash_sales_df.drop_duplicates(subset=['order_key'])
            cross_year_wash_sales_df = cross_year_wash_sales_df.drop(columns=['order_key'])
    
    # Debug cross-year wash sales
    if not cross_year_wash_sales_df.empty:
        print(f"Total cross-year wash sales: {len(cross_year_wash_sales_df)}")
        print(f"Affected symbols: {cross_year_wash_sales_df['symbol'].unique()}")
        print(f"Year combinations: {cross_year_wash_sales_df[['sell_year', 'buy_year']].drop_duplicates().values}")
    else:
        print("No cross-year wash sales detected.")
    
    # Prepare summary statistics
    summary = {
        'total_wash_sales': len(wash_sales_df),
        'total_disallowed_loss': wash_sales_df['disallowed_loss'].sum() if not wash_sales_df.empty else 0,
        'affected_symbols': wash_sales_df['symbol'].nunique() if not wash_sales_df.empty else 0,
        'tax_loss_harvest_opportunities': len(tax_loss_harvest_df),
        'potential_tax_savings': tax_loss_harvest_df['realized_loss'].sum() if not tax_loss_harvest_df.empty else 0,
        'cross_year_wash_sales': len(cross_year_wash_sales_df),
        'cross_year_disallowed_loss': cross_year_wash_sales_df['disallowed_loss'].sum() if not cross_year_wash_sales_df.empty else 0
    }
    
    return {
        'wash_sales': wash_sales_df,
        'summary': summary,
        'tax_loss_harvest': tax_loss_harvest_df,
        'multi_year': cross_year_wash_sales_df
    }


def find_tax_loss_harvesting_opportunities(df, min_loss_threshold=1.0):
    """
    Identify potential tax loss harvesting opportunities from transaction data.
    
    Args:
        df: DataFrame with columns: date, symbol, side, quantity, price
        min_loss_threshold: Minimum dollar loss to consider as a tax loss harvesting opportunity
        
    Returns:
        DataFrame with tax loss harvesting opportunities
    """
    # Ensure columns are properly formatted
    required_columns = ['date', 'symbol', 'side', 'quantity', 'price']
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Required column '{col}' missing from input data")
    
    # Ensure df is sorted by date
    df = df.sort_values('date').reset_index(drop=True)
    
    # Convert sides to lowercase for consistent comparison
    df['side'] = df['side'].str.lower()
    
    # Add year column
    df['year'] = df['date'].dt.year
    
    # Get current positions (group by symbol)
    positions = {}
    
    # Process all trades to build current positions
    for _, row in df.iterrows():
        symbol = row['symbol']
        side = row['side']
        quantity = row['quantity']
        price = row['price']
        date = row['date']
        
        if symbol not in positions:
            positions[symbol] = {
                'quantity': 0,
                'cost_basis': 0,
                'last_price': price,
                'last_date': date
            }
        
        # Update position
        if 'buy' in side:
            # Calculate new cost basis with this purchase
            current_value = positions[symbol]['quantity'] * positions[symbol]['cost_basis']
            new_value = quantity * price
            new_quantity = positions[symbol]['quantity'] + quantity
            if new_quantity > 0:
                positions[symbol]['cost_basis'] = (current_value + new_value) / new_quantity
            positions[symbol]['quantity'] += quantity
        elif 'sell' in side:
            positions[symbol]['quantity'] -= quantity
        
        # Update last price
        positions[symbol]['last_price'] = price
        positions[symbol]['last_date'] = date
    
    # Find tax loss harvesting opportunities
    opportunities = []
    
    # Current year for tax purposes
    current_year = df['date'].max().year
    
    for symbol, data in positions.items():
        # Only consider positions with positive quantity
        if data['quantity'] > 0:
            unrealized_gain_loss = (data['last_price'] - data['cost_basis']) * data['quantity']
            
            # If there's a loss greater than threshold, it's a potential opportunity
            if unrealized_gain_loss < -min_loss_threshold:
                opportunities.append({
                    'symbol': symbol,
                    'quantity': data['quantity'],
                    'cost_basis': data['cost_basis'],
                    'current_price': data['last_price'],
                    'unrealized_loss': -unrealized_gain_loss,  # Make positive for better readability
                    'percentage_loss': ((data['last_price'] / data['cost_basis']) - 1) * 100,
                    'last_updated': data['last_date'],
                    'tax_year': current_year
                })
    
    return pd.DataFrame(opportunities)
