import streamlit as st
import pandas as pd
import numpy as np
import datetime
import io
from wash_sale_detector import detect_wash_sales, find_tax_loss_harvesting_opportunities
from utils import format_currency, format_percentage, parse_date_column

# Page configuration
st.set_page_config(
    page_title="Wash Sale Detector",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# App title and header
st.title("Investment Wash Sale & Tax Loss Harvesting Tool")

# Header image
col1, col2, col3 = st.columns([1, 3, 1])
with col2:
    st.image("https://images.unsplash.com/photo-1542744173-05336fcc7ad4", 
             caption="Financial analysis dashboard")

# Sidebar with explanation
with st.sidebar:
    st.header("About Wash Sales")
    st.write("""
    A wash sale occurs when you sell a security at a loss and, within 30 days before 
    or after the sale, you:
    
    1. Buy substantially identical securities
    2. Acquire substantially identical securities in a fully taxable trade
    3. Acquire a contract or option to buy substantially identical securities
    
    The IRS disallows tax deductions for wash sales. This tool helps you identify 
    potential wash sale transactions in your portfolio.
    """)
    
    st.divider()
    
    st.header("About Tax Loss Harvesting")
    st.write("""
    Tax loss harvesting is a strategy to offset capital gains by selling securities at a loss.
    This can help reduce your overall tax liability. However, be careful to avoid wash sale
    rules which could disallow these losses.
    
    This tool helps identify:
    - Current positions with unrealized losses that could be harvested
    - Historical tax losses that were successfully realized
    - Cross-year wash sales that affect tax reporting
    """)
    
    st.divider()
    
    st.image("https://images.unsplash.com/photo-1551288049-bebda4e38f71", 
             caption="Data analysis")
    
    st.header("How to Use")
    st.write("""
    1. Upload a CSV file with your trading data
    2. Select analysis options (wash sales, tax loss harvesting, etc.)
    3. Review detected insights and recommendations
    4. Export results for your tax documentation
    """)

# File upload section
st.subheader("Upload Trading Data")

# Sample format information
with st.expander("CSV Format Information"):
    st.write("""
    Your CSV file should include the following minimum columns:
    - Date/time of trade
    - Symbol/ticker 
    - Side (buy or sell)
    - Quantity
    - Price
    
    The tool supports various broker export formats. Make sure your CSV file 
    includes these essential data points for accurate analysis.
    """)
    
    st.code("""
    Example formats:
    1. Alpaca: Symbol,Time,Side,Quantity,Price
    2. Generic: Date,Symbol,Side,Shares,Price
    """)

# Upload file UI
st.write("**Upload one or more CSV files containing your trading history**")
st.info("""
You can now upload multiple files for comprehensive analysis across different time periods or accounts.
This is especially useful for analyzing cross-year wash sales and tracking positions across multiple statements.
""")
uploaded_files = st.file_uploader("Choose CSV file(s)", type=["csv"], accept_multiple_files=True)

# Sample result container
result_container = st.container()

if uploaded_files:
    try:
        # Initialize an empty dataframe to hold all data
        all_data = pd.DataFrame()
        
        # Process each uploaded file
        for uploaded_file in uploaded_files:
            # Load the data
            file_df = pd.read_csv(uploaded_file)
            
            # Add a column to track which file the data came from
            file_df['source_file'] = uploaded_file.name
            
            # Append to the combined dataframe
            all_data = pd.concat([all_data, file_df], ignore_index=True)
        
        # Use the combined dataframe for analysis
        df = all_data
        
        # Show raw data
        with st.expander("Raw Transaction Data"):
            st.write(f"Loaded {len(uploaded_files)} file(s) with a total of {len(df)} transactions")
            
            # Show file summary if multiple files were uploaded
            if len(uploaded_files) > 1:
                st.subheader("Files Summary")
                file_summary = df.groupby('source_file').size().reset_index()
                file_summary.columns = ['File Name', 'Transaction Count']
                
                # Try to find a date column and add summary later
                try:
                    # We need to guess the date column for the summary
                    date_column_guess = next((col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()), df.columns[0])
                    
                    # Parse the guessed date column
                    temp_df = df.copy()
                    temp_df['parsed_date'] = parse_date_column(df[date_column_guess])
                    
                    # Get min and max dates for each file
                    date_ranges = temp_df.groupby('source_file').agg({'parsed_date': ['min', 'max']})
                    date_ranges.columns = ['Start Date', 'End Date']
                    date_ranges = date_ranges.reset_index()
                    
                    # Merge the summaries
                    file_summary = pd.merge(file_summary, date_ranges, left_on='File Name', right_on='source_file')
                    
                    # Date column found, include date range info
                    st.dataframe(
                        file_summary,
                        column_config={
                            "File Name": st.column_config.TextColumn("File Name"),
                            "Transaction Count": st.column_config.NumberColumn("Transactions"),
                            "Start Date": st.column_config.DatetimeColumn("Start Date"),
                            "End Date": st.column_config.DatetimeColumn("End Date")
                        },
                        hide_index=True
                    )
                except Exception as e:
                    # If date parsing fails, just show file count summary
                    st.dataframe(
                        file_summary,
                        column_config={
                            "File Name": st.column_config.TextColumn("File Name"),
                            "Transaction Count": st.column_config.NumberColumn("Transactions")
                        },
                        hide_index=True
                    )
                    st.warning("Could not determine date ranges for files. Please select the proper date column below.")
            
            # Display all data
            st.dataframe(df)
        
        # Automatic column detection
        st.subheader("Column Mapping")
        st.info("Select the appropriate columns from your CSV file")
        
        # Column selection
        col_options = df.columns.tolist()
        
        col1, col2 = st.columns(2)
        with col1:
            date_col = st.selectbox("Date/Time column", 
                                    options=col_options,
                                    index=next((i for i, col in enumerate(col_options) 
                                           if 'date' in col.lower() or 'time' in col.lower()), 0))
            
            symbol_col = st.selectbox("Symbol/Ticker column", 
                                     options=col_options,
                                     index=next((i for i, col in enumerate(col_options) 
                                            if 'symbol' in col.lower() or 'ticker' in col.lower()), 0))
            
            side_col = st.selectbox("Transaction Side column (buy/sell)", 
                                   options=col_options,
                                   index=next((i for i, col in enumerate(col_options) 
                                          if col.lower() == 'side'), 
                                         next((i for i, col in enumerate(col_options) 
                                          if 'side' in col.lower() or 'type' in col.lower()), 0)))
        
        with col2:
            quantity_col = st.selectbox("Quantity column", 
                                       options=col_options,
                                       index=next((i for i, col in enumerate(col_options) 
                                              if 'quant' in col.lower() or 'shares' in col.lower() or 'amount' in col.lower()), 0))
            
            price_col = st.selectbox("Price column", 
                                    options=col_options,
                                    index=next((i for i, col in enumerate(col_options) 
                                           if 'price' in col.lower() or 'cost' in col.lower()), 0))
            
            filled_price_col = st.selectbox("Filled Price column (if different)", 
                                           options=['None'] + col_options,
                                           index=0)
        
        # If "None" is selected, use price column
        if filled_price_col == 'None':
            filled_price_col = price_col
        
        # Analysis Options
        st.subheader("Analysis Options")
        
        analysis_col1, analysis_col2 = st.columns(2)
        with analysis_col1:
            window_days = st.slider(
                "Wash Sale Window (days)", 
                min_value=1, 
                max_value=60, 
                value=30,
                help="Number of days before and after a sale to check for wash sales. IRS standard is 30 days."
            )
            
            min_loss_threshold = st.number_input(
                "Minimum Loss for Tax Harvesting ($)", 
                min_value=0.0, 
                value=1.0, 
                step=1.0,
                help="Minimum dollar loss to consider as a potential tax loss harvesting opportunity."
            )
        
        with analysis_col2:
            year_end_analysis = st.checkbox(
                "Enable Multi-Year Analysis", 
                value=True,
                help="Analyze wash sales that cross tax years, which have special reporting requirements."
            )
            
            show_tax_loss_harvesting = st.checkbox(
                "Include Tax Loss Harvesting Analysis", 
                value=True,
                help="Identify potential tax loss harvesting opportunities and historical realized losses."
            )
            
        # Analysis button
        if st.button("Run Analysis", type="primary"):
            with st.spinner("Analyzing transactions..."):
                # Prepare the dataframe for analysis
                analysis_data = pd.DataFrame()
                analysis_data['date'] = parse_date_column(df[date_col])
                analysis_data['symbol'] = df[symbol_col]
                analysis_data['side'] = df[side_col]
                analysis_data['quantity'] = df[quantity_col].astype(float)
                analysis_data['price'] = df[filled_price_col if filled_price_col != 'None' else price_col].astype(float)
                
                # Add Order ID if available to prevent duplicate detection
                order_id_col = next((col for col in df.columns if 'order' in col.lower() and 'id' in col.lower()), None)
                if order_id_col:
                    analysis_data['order_id'] = df[order_id_col]
                
                # Add source file info if available
                if 'source_file' in df.columns:
                    analysis_data['source_file'] = df['source_file']
                
                # Run the wash sale detection
                results = detect_wash_sales(
                    analysis_data,
                    window_days=window_days,
                    year_end_analysis=year_end_analysis
                )
                
                # Create tabs for different analyses
                tabs = st.tabs(["Wash Sales", "Tax Loss Harvesting", "Multi-Year Analysis"])
                
                # Wash Sales Tab
                with tabs[0]:
                    if results['wash_sales'].empty:
                        st.success("No wash sales detected in your transactions.")
                    else:
                        # Show wash sale summary
                        st.subheader("Wash Sale Analysis Results")
                        
                        # Summary metrics
                        metrics_col1, metrics_col2, metrics_col3 = st.columns(3)
                        
                        total_wash_sale_count = len(results['wash_sales'])
                        total_disallowed_loss = results['wash_sales']['disallowed_loss'].sum()
                        affected_symbols = results['wash_sales']['symbol'].nunique()
                        
                        metrics_col1.metric(
                            "Total Wash Sales Detected", 
                            f"{total_wash_sale_count}")
                        
                        metrics_col2.metric(
                            "Total Disallowed Loss", 
                            format_currency(total_disallowed_loss))
                        
                        metrics_col3.metric(
                            "Affected Symbols", 
                            f"{affected_symbols}")
                        
                        # Wash sales table
                        # Prepare column configuration
                        wash_column_config = {
                            "sell_date": st.column_config.DatetimeColumn("Sell Date"),
                            "symbol": st.column_config.TextColumn("Symbol"),
                            "sell_quantity": st.column_config.NumberColumn("Sell Qty", format="%.4f"),
                            "sell_price": st.column_config.NumberColumn("Sell Price", format="$%.2f"),
                            "buy_date": st.column_config.DatetimeColumn("Buy Date"),
                            "buy_quantity": st.column_config.NumberColumn("Buy Qty", format="%.4f"),
                            "buy_price": st.column_config.NumberColumn("Buy Price", format="$%.2f"),
                            "days_between": st.column_config.NumberColumn("Days"),
                            "loss_per_share": st.column_config.NumberColumn("Loss/Share", format="$%.2f"),
                            "disallowed_loss": st.column_config.NumberColumn("Disallowed Loss", format="$%.2f"),
                        }
                        
                        # Add Order ID columns if they exist
                        if 'sell_order_id' in results['wash_sales'].columns:
                            wash_column_config["sell_order_id"] = st.column_config.TextColumn("Sell Order ID")
                        if 'buy_order_id' in results['wash_sales'].columns:
                            wash_column_config["buy_order_id"] = st.column_config.TextColumn("Buy Order ID")
                            
                        # Add source file columns if they exist
                        if 'sell_file' in results['wash_sales'].columns:
                            wash_column_config["sell_file"] = st.column_config.TextColumn("Sell File")
                        if 'buy_file' in results['wash_sales'].columns:
                            wash_column_config["buy_file"] = st.column_config.TextColumn("Buy File")
                            
                        st.dataframe(
                            results['wash_sales'],
                            column_config=wash_column_config,
                            hide_index=True,
                            use_container_width=True
                        )
                        
                        # Download button for results
                        csv = results['wash_sales'].to_csv(index=False)
                        st.download_button(
                            label="Download Wash Sale Report (CSV)",
                            data=csv,
                            file_name="wash_sale_report.csv",
                            mime="text/csv",
                            key="download-csv"
                        )
                        
                        # Symbol breakdown
                        st.subheader("Wash Sales by Symbol")
                        
                        # Group by symbol
                        symbol_summary = results['wash_sales'].groupby('symbol').agg({
                            'disallowed_loss': 'sum',
                            'symbol': 'count'
                        }).rename(columns={'symbol': 'count'}).reset_index()
                        
                        symbol_summary = symbol_summary.sort_values('disallowed_loss', ascending=False)
                        
                        # Display each symbol's wash sales
                        for _, row in symbol_summary.iterrows():
                            symbol = row['symbol']
                            symbol_wash_count = row['count']
                            symbol_total_loss = row['disallowed_loss']
                            
                            with st.expander(f"{symbol}: {symbol_wash_count} wash sales (${symbol_total_loss:.2f} disallowed)"):
                                symbol_data = results['wash_sales'][results['wash_sales']['symbol'] == symbol]
                                
                                # Prepare column configuration for symbol breakdown
                                symbol_column_config = {
                                    "sell_date": st.column_config.DatetimeColumn("Sell Date"),
                                    "sell_quantity": st.column_config.NumberColumn("Sell Qty", format="%.4f"),
                                    "sell_price": st.column_config.NumberColumn("Sell Price", format="$%.2f"),
                                    "buy_date": st.column_config.DatetimeColumn("Buy Date"),
                                    "buy_quantity": st.column_config.NumberColumn("Buy Qty", format="%.4f"),
                                    "buy_price": st.column_config.NumberColumn("Buy Price", format="$%.2f"),
                                    "days_between": st.column_config.NumberColumn("Days"),
                                    "loss_per_share": st.column_config.NumberColumn("Loss/Share", format="$%.2f"),
                                    "disallowed_loss": st.column_config.NumberColumn("Disallowed Loss", format="$%.2f"),
                                }
                                
                                # Add Order ID columns if they exist
                                if 'sell_order_id' in symbol_data.columns:
                                    symbol_column_config["sell_order_id"] = st.column_config.TextColumn("Sell Order ID")
                                if 'buy_order_id' in symbol_data.columns:
                                    symbol_column_config["buy_order_id"] = st.column_config.TextColumn("Buy Order ID")
                                    
                                # Add source file columns if they exist
                                if 'sell_file' in symbol_data.columns:
                                    symbol_column_config["sell_file"] = st.column_config.TextColumn("Sell File")
                                if 'buy_file' in symbol_data.columns:
                                    symbol_column_config["buy_file"] = st.column_config.TextColumn("Buy File")
                                
                                st.dataframe(
                                    symbol_data,
                                    column_config=symbol_column_config,
                                    hide_index=True
                                )
                
                # Tax Loss Harvesting Tab
                with tabs[1]:
                    if show_tax_loss_harvesting:
                        # Find current tax loss harvesting opportunities
                        tlh_opportunities = find_tax_loss_harvesting_opportunities(
                            analysis_data,
                            min_loss_threshold=min_loss_threshold
                        )
                        
                        # Tax loss harvest past records from the detection function
                        past_tax_losses = results['tax_loss_harvest']
                        
                        # Current opportunities section
                        st.subheader("Current Tax Loss Harvesting Opportunities")
                        
                        if tlh_opportunities.empty:
                            st.info("No current tax loss harvesting opportunities found in your portfolio.")
                        else:
                            # Summary metrics for TLH
                            tlh_col1, tlh_col2, tlh_col3 = st.columns(3)
                            
                            total_opportunity_count = len(tlh_opportunities)
                            total_unrealized_loss = tlh_opportunities['unrealized_loss'].sum()
                            avg_loss_percentage = tlh_opportunities['percentage_loss'].mean()
                            
                            tlh_col1.metric(
                                "Opportunities Identified", 
                                f"{total_opportunity_count}")
                            
                            tlh_col2.metric(
                                "Total Unrealized Loss", 
                                format_currency(total_unrealized_loss))
                            
                            tlh_col3.metric(
                                "Average Loss", 
                                format_percentage(avg_loss_percentage))
                            
                            # Tax loss harvesting opportunities table
                            st.dataframe(
                                tlh_opportunities,
                                column_config={
                                    "symbol": st.column_config.TextColumn("Symbol"),
                                    "quantity": st.column_config.NumberColumn("Quantity", format="%.4f"),
                                    "cost_basis": st.column_config.NumberColumn("Cost Basis", format="$%.2f"),
                                    "current_price": st.column_config.NumberColumn("Current Price", format="$%.2f"),
                                    "unrealized_loss": st.column_config.NumberColumn("Unrealized Loss", format="$%.2f"),
                                    "percentage_loss": st.column_config.NumberColumn("Loss %", format="%.2f%%"),
                                    "last_updated": st.column_config.DatetimeColumn("Last Updated"),
                                    "tax_year": st.column_config.NumberColumn("Tax Year")
                                },
                                hide_index=True,
                                use_container_width=True
                            )
                            
                            # Download TLH opportunities
                            tlh_csv = tlh_opportunities.to_csv(index=False)
                            st.download_button(
                                label="Download TLH Opportunities (CSV)",
                                data=tlh_csv,
                                file_name="tax_loss_harvest_opportunities.csv",
                                mime="text/csv",
                                key="download-tlh-csv"
                            )
                        
                        # Past realized losses section
                        st.subheader("Historical Tax Losses Realized")
                        
                        if past_tax_losses.empty:
                            st.info("No historical tax losses detected in your transactions.")
                        else:
                            # Summary metrics for historical losses
                            past_col1, past_col2, past_col3 = st.columns(3)
                            
                            total_past_count = len(past_tax_losses)
                            total_realized_loss = past_tax_losses['realized_loss'].sum()
                            
                            # Group by year
                            year_summary = past_tax_losses.groupby('year').agg({
                                'realized_loss': 'sum'
                            }).reset_index()
                            
                            past_col1.metric(
                                "Total Realized Losses", 
                                f"{total_past_count}")
                            
                            past_col2.metric(
                                "Total Loss Amount", 
                                format_currency(total_realized_loss))
                            
                            # Historical realized losses table
                            st.dataframe(
                                past_tax_losses,
                                column_config={
                                    "date": st.column_config.DatetimeColumn("Sale Date"),
                                    "symbol": st.column_config.TextColumn("Symbol"),
                                    "quantity": st.column_config.NumberColumn("Quantity", format="%.4f"),
                                    "sell_price": st.column_config.NumberColumn("Sell Price", format="$%.2f"),
                                    "cost_basis": st.column_config.NumberColumn("Cost Basis", format="$%.2f"),
                                    "realized_loss": st.column_config.NumberColumn("Realized Loss", format="$%.2f"),
                                    "year": st.column_config.NumberColumn("Tax Year")
                                },
                                hide_index=True,
                                use_container_width=True
                            )
                            
                            # Year breakdown
                            st.subheader("Tax Losses by Year")
                            
                            for _, row in year_summary.iterrows():
                                year = row['year']
                                year_loss = row['realized_loss']
                                
                                st.metric(
                                    f"Tax Year {year}", 
                                    format_currency(year_loss)
                                )
                    else:
                        st.info("Enable Tax Loss Harvesting Analysis in the options to see potential opportunities.")
                
                # Multi-Year Analysis Tab
                with tabs[2]:
                    if year_end_analysis:
                        cross_year_sales = results['multi_year']
                        
                        # Debug information about the years in the dataset
                        unique_years = sorted(analysis_data['date'].dt.year.unique())
                        st.write(f"Years found in your data: {', '.join(map(str, unique_years))}")
                        
                        if len(unique_years) < 2:
                            st.warning("""
                            **Note:** Your data appears to contain transactions from only one year. 
                            To detect cross-year wash sales, please upload data that spans multiple tax years.
                            """)
                        
                        if cross_year_sales.empty:
                            st.info("No cross-year wash sales detected in your transactions.")
                        else:
                            st.subheader("Cross-Year Wash Sales")
                            st.warning("""
                            **Important Tax Consideration:** Wash sales that span across different tax years 
                            require special attention for tax reporting. These cross-year wash sales may affect 
                            your tax liability differently compared to wash sales within the same tax year.
                            """)
                            
                            # Summary metrics
                            cy_col1, cy_col2, cy_col3 = st.columns(3)
                            
                            total_cy_count = len(cross_year_sales)
                            total_cy_loss = cross_year_sales['disallowed_loss'].sum()
                            affected_symbols = cross_year_sales['symbol'].nunique()
                            
                            cy_col1.metric(
                                "Cross-Year Wash Sales", 
                                f"{total_cy_count}")
                            
                            cy_col2.metric(
                                "Total Disallowed Loss", 
                                format_currency(total_cy_loss))
                                
                            cy_col3.metric(
                                "Affected Symbols",
                                f"{affected_symbols}")
                            
                            # Show unique year combinations
                            st.subheader("Year Combinations")
                            year_combos = cross_year_sales[['sell_year', 'buy_year']].drop_duplicates()
                            
                            for _, row in year_combos.iterrows():
                                sell_year = row['sell_year']
                                buy_year = row['buy_year']
                                count = len(cross_year_sales[
                                    (cross_year_sales['sell_year'] == sell_year) & 
                                    (cross_year_sales['buy_year'] == buy_year)
                                ])
                                
                                st.write(f"**{sell_year} → {buy_year}**: {count} wash sale(s)")
                            
                            # Cross-year wash sales table
                            st.subheader("Detailed Cross-Year Wash Sales")
                            
                            # Check if source file info is available
                            column_config = {
                                "sell_date": st.column_config.DatetimeColumn("Sell Date"),
                                "sell_year": st.column_config.NumberColumn("Sell Year"),
                                "symbol": st.column_config.TextColumn("Symbol"),
                                "sell_price": st.column_config.NumberColumn("Sell Price", format="$%.2f"),
                                "buy_date": st.column_config.DatetimeColumn("Buy Date"),
                                "buy_year": st.column_config.NumberColumn("Buy Year"),
                                "buy_price": st.column_config.NumberColumn("Buy Price", format="$%.2f"),
                                "disallowed_loss": st.column_config.NumberColumn("Disallowed Loss", format="$%.2f"),
                                "days_between": st.column_config.NumberColumn("Days Between")
                            }
                            
                            # Add Order ID columns if they exist
                            if 'sell_order_id' in cross_year_sales.columns:
                                column_config["sell_order_id"] = st.column_config.TextColumn("Sell Order ID")
                            if 'buy_order_id' in cross_year_sales.columns:
                                column_config["buy_order_id"] = st.column_config.TextColumn("Buy Order ID")
                                
                            # Add source file columns if they exist
                            if 'sell_file' in cross_year_sales.columns:
                                column_config["sell_file"] = st.column_config.TextColumn("Sell File")
                            if 'buy_file' in cross_year_sales.columns:
                                column_config["buy_file"] = st.column_config.TextColumn("Buy File")
                            
                            st.dataframe(
                                cross_year_sales,
                                column_config=column_config,
                                hide_index=True,
                                use_container_width=True
                            )
                            
                            # Download cross-year report
                            cy_csv = cross_year_sales.to_csv(index=False)
                            st.download_button(
                                label="Download Cross-Year Report (CSV)",
                                data=cy_csv,
                                file_name="cross_year_wash_sales.csv",
                                mime="text/csv",
                                key="download-cy-csv"
                            )
                            
                            # Symbol breakdown
                            st.subheader("Cross-Year Wash Sales by Symbol")
                            
                            # Group by symbol for cross-year wash sales
                            cy_symbol_summary = cross_year_sales.groupby('symbol').agg({
                                'disallowed_loss': 'sum',
                                'symbol': 'count'
                            }).rename(columns={'symbol': 'count'}).reset_index()
                            
                            cy_symbol_summary = cy_symbol_summary.sort_values('disallowed_loss', ascending=False)
                            
                            # Display each symbol's cross-year wash sales
                            for _, row in cy_symbol_summary.iterrows():
                                symbol = row['symbol']
                                symbol_wash_count = row['count']
                                symbol_total_loss = row['disallowed_loss']
                                
                                with st.expander(f"{symbol}: {symbol_wash_count} cross-year wash sales (${symbol_total_loss:.2f} disallowed)"):
                                    symbol_data = cross_year_sales[cross_year_sales['symbol'] == symbol]
                                    
                                    # Prepare column configuration for symbol breakdown
                                    cy_symbol_column_config = {
                                        "sell_date": st.column_config.DatetimeColumn("Sell Date"),
                                        "sell_year": st.column_config.NumberColumn("Sell Year"),
                                        "sell_price": st.column_config.NumberColumn("Sell Price", format="$%.2f"),
                                        "buy_date": st.column_config.DatetimeColumn("Buy Date"),
                                        "buy_year": st.column_config.NumberColumn("Buy Year"),
                                        "buy_price": st.column_config.NumberColumn("Buy Price", format="$%.2f"),
                                        "days_between": st.column_config.NumberColumn("Days"),
                                        "disallowed_loss": st.column_config.NumberColumn("Disallowed Loss", format="$%.2f"),
                                    }
                                    
                                    # Add Order ID columns if they exist
                                    if 'sell_order_id' in symbol_data.columns:
                                        cy_symbol_column_config["sell_order_id"] = st.column_config.TextColumn("Sell Order ID") 
                                    if 'buy_order_id' in symbol_data.columns:
                                        cy_symbol_column_config["buy_order_id"] = st.column_config.TextColumn("Buy Order ID")
                                        
                                    # Add source file columns if they exist
                                    if 'sell_file' in symbol_data.columns:
                                        cy_symbol_column_config["sell_file"] = st.column_config.TextColumn("Sell File")
                                    if 'buy_file' in symbol_data.columns:
                                        cy_symbol_column_config["buy_file"] = st.column_config.TextColumn("Buy File")
                                    
                                    st.dataframe(
                                        symbol_data,
                                        column_config=cy_symbol_column_config,
                                        hide_index=True
                                    )
                    else:
                        st.info("Enable Multi-Year Analysis in the options to see cross-year wash sales.")
                    
    except Exception as e:
        st.error(f"Error processing file: {str(e)}")
        st.exception(e)

# Footer
st.markdown("""
---
### Disclaimer
This tool is provided for informational purposes only and does not constitute financial or tax advice. 
Always consult with a qualified tax professional about your specific situation.
""")
